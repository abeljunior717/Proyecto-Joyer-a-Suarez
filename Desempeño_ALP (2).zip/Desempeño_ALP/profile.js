// profile.js - Manejo del perfil del usuario
document.addEventListener('DOMContentLoaded', function() {
    // Verificar autenticación
    const token = localStorage.getItem('userToken');
    if (!token) {
        window.location.href = 'login.html';
        return;
    }

    // Mostrar nombre en el header
    const userName = localStorage.getItem('userName');
    if (userName) {
        document.getElementById('header-username').textContent = `Bienvenido, ${userName}`;
    }

    // Cargar datos del perfil
    async function loadProfile() {
        try {
            const response = await fetch('/api/users/me', {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            
            const userData = await response.json();
            
            if (response.ok) {
                document.getElementById('profile-name').value = userData.name;
                document.getElementById('profile-email').value = userData.email;
                document.getElementById('profile-address').value = userData.address;
                document.getElementById('profile-phone').value = userData.phone;
            } else {
                showNotification('Error al cargar perfil', 'error');
            }
        } catch (error) {
            showNotification('Error de conexión', 'error');
        }
    }

    // Actualizar perfil
    const profileForm = document.getElementById('profile-form');
    if (profileForm) {
        profileForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const updatedData = {
                name: document.getElementById('profile-name').value,
                address: document.getElementById('profile-address').value,
                phone: document.getElementById('profile-phone').value
            };

            try {
                const response = await fetch('/api/users/me', {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify(updatedData)
                });

                if (response.ok) {
                    showNotification('Perfil actualizado correctamente', 'success');
                    localStorage.setItem('userName', updatedData.name);
                    document.getElementById('header-username').textContent = `Bienvenido, ${updatedData.name}`;
                } else {
                    const error = await response.json();
                    showNotification(error.message || 'Error al actualizar', 'error');
                }
            } catch (error) {
                showNotification('Error de conexión', 'error');
            }
        });
    }

    // Cambiar contraseña
    const passwordForm = document.getElementById('password-form');
    if (passwordForm) {
        passwordForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const passwords = {
                currentPassword: document.getElementById('current-password').value,
                newPassword: document.getElementById('new-password').value
            };

            if (passwords.newPassword !== document.getElementById('confirm-new-password').value) {
                showNotification('Las contraseñas no coinciden', 'error');
                return;
            }

            try {
                const response = await fetch('/api/users/change-password', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': `Bearer ${token}`
                    },
                    body: JSON.stringify(passwords)
                });

                if (response.ok) {
                    showNotification('Contraseña cambiada correctamente', 'success');
                    passwordForm.reset();
                } else {
                    const error = await response.json();
                    showNotification(error.message || 'Error al cambiar contraseña', 'error');
                }
            } catch (error) {
                showNotification('Error de conexión', 'error');
            }
        });
    }

    // Cargar datos iniciales
    loadProfile();
});